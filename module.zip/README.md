bindhosts

fully standalone, self-updating, hosts-based-adblocking implementation

(🚨 Adaway incompatible ❌)
  
  ...
  
  
  1.4.2 - 1.4.8
   - custom rules, modifiable sources, blacklist and whitelist support
   - optimize and check for other downloaders
   - fully implemented, self-updating, standalone hosts-based-adblocking
   - fork off and kill adaway compatibility (uses ksu mount)
   - detect user changes, fix localhost bug
   - fixup! apatch's environment detection
   - account custom rules, misc housekeeping stuff
   - implement [ZN-hostsredirect](https://github.com/aviraxp/ZN-hostsredirect) helper mode (requires zygisk next)

  1.5.0
    - misc cleanups, adjust rules a bit


Hiding: 

  - APatch - [ZN-hostsredirect](https://github.com/aviraxp/ZN-hostsredirect) 

  - KernelSU - Umount Modules, if no umount, [ZN-hostsredirect](https://github.com/aviraxp/ZN-hostsredirect) 

  - Magisk - Denylist, Shamiko


[Download](https://raw.githubusercontent.com/backslashxx/bindhosts/standalone/module.zip)

[report for any issues](https://github.com/backslashxx/bindhosts/issues)
