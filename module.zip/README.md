bindhosts

fully standalone, self-updating, hosts-based-adblocking implementation

(🚨 Adaway incompatible ❌)
  
  ...
  
  
  1.4.2 - 1.4.5
   - custom rules, modifiable sources, blacklist and whitelist support
   - optimize and check for other downloaders
   - fully implemented, self-updating, standalone hosts-based-adblocking
   - fork off and kill adaway compatibility (uses ksu mount)
   - detect user changes, fix localhost bug
     
  1.4.7
   - fixup! apatch's environment detection
   


[Download](https://raw.githubusercontent.com/backslashxx/bindhosts/standalone/module.zip)

[report for any issues](https://github.com/backslashxx/bindhosts/issues)
