bindhosts

fully standalone, self-updating, hosts-based-adblocking implementation

(🚨 Adaway incompatible 👌)
  
  
  
  1.4.2 - 1.5.4
   - custom rules, modifiable sources, blacklist and whitelist support
   - fully implemented, self-updating, standalone hosts-based-adblocking
   - fork off and kill adaway compatibility (uses ksu mount)
   - detect user changes, fix localhost bug
   - account custom rules, misc housekeeping stuff
   - helper modes added: [ZN-hostsredirect](https://github.com/aviraxp/ZN-hostsredirect), [hosts_file_redirect](https://github.com/AndroidPatch/kpm/tree/main/src/hosts_file_redirect)
   - fixup whitelist processing, rare update failures
      
  1.5.5
   - housekeeping stuff

Hiding: 

  - APatch - hosts_file_redirect [how-to](https://github.com/backslashxx/bindhosts/issues/3#issue-2640292721), or ZN-hostsredirect

  - KernelSU - Umount Modules or ZN-hostsredirect

  - Magisk - Denylist, Shamiko


[Download](https://raw.githubusercontent.com/backslashxx/bindhosts/standalone/module.zip)

[report for any issues](https://github.com/backslashxx/bindhosts/issues)
