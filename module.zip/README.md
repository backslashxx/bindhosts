bindhosts

fully standalone, self-updating, hosts-based-adblocking implementation

(🚨 Adaway incompatible ❌)
  
  ...
  
  
  1.4.2 - 1.4.4
   - custom rules, modifiable sources, blacklist and whitelist support
   - optimize and check for other downloaders
   - fully implemented, self-updating, standalone hosts-based-adblocking
   
  1.4.5 
   - fork off and kill adaway compatibility (uses ksu mount)
   - detect user changes, fix localhost bug


[report for any issues](https://github.com/backslashxx/bindhosts/issues)

