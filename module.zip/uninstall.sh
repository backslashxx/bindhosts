rm -rf /data/adb/bindhosts
