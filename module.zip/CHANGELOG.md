## bindhosts
Systemless hosts for Apatch, KernelSU and Magisk

---

# Changelog
### 1.6.5-dev
- unify two codebases, ahemm scriptbases
- development version, need testers
- fixups on that operating_mode system

### 1.4.2 - 1.6.3
- custom rules, modifiable sources, blacklist and whitelist support
- optimizations and check for other downloaders
- detect user changes, fix localhost bug
- leverage skip mount, migrate to compat
- Adaway coexistence handling
- fixups: whitelist processing, rare update failures
- /data/adb/bindhosts migration  
- webui on supported managers - KOWX712
- small fixups